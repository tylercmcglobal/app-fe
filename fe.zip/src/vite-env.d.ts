/// <reference types="vite/client" />
declare module 'socket.io-mock';